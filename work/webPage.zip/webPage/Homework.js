// Lenny, Kitty, 9/18/2016

// Problem 1 
var numArray = [18, 24, 57, 98, 45, 27, 3, 456, 3, 35, 85];
var i = numArray[5];
console.log(i);


// Problem 2 
var sum;
for (var i = numArray.length; i >= 0; i--) {
    sum += numArray[i];
}

// Problem 3
var numArray2 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
var last = numArray2.pop();
console.log(numArray2);

// Problem 4 
var num1 = 12;
var num2 = 13;
var sum = num1 + num2;

function addNums(num1, num2) {
    var sum = num1 + num2;
    if (sum <= 25) {
        console.log("True");
    } else { console.log("False"); }
}
addNums(num1, num2);
// Problem 5 
var string1 = "new";
var string2 = "string";

function combineStrings(string1, string2) {
    var combinedString = string1 + " " + string2;
    if (combinedString.length > 12) {
        console.log("Error, string too long.");
    } else { return combinedString; }
}

combineStrings(string1, string2);

var number1 = 0;
// Problem 6
while (number1 <= 20) {
    if (number1 < 6) {
        console.log("Very Low Number");
    } else if (number1 >= 6 && number1 <= 10) {
        console.log("Low Number");
    } else if (number1 >= 11 && number1 <= 15) {
        console.log("High Number");
    } else {
        console.log("Very High Number");
    }
    number1++;
}